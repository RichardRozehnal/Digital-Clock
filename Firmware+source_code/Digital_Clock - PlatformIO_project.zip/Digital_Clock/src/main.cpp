//--------------------------------------------------//
// DIGITAL CLOCK, code by Richard Rozehnal / 3.2024 //
//--------------------------------------------------//

#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>

#define SCLK       PA5      // pin 11
#define MISO       PA6      // pin 12
#define MOSI       PA7      // pin 13
#define LAT1       PA4      // pin 10
#define BLANK1     PA2      // pin  8 
#define LAT2       PA3      // pin  9
#define BLANK2     PA1      // pin  7
#define SDA       PA10      // pin 18
#define SCL        PA9      // pin 17
#define MAIN_SET   PA0      // pin  6
#define UP_SET    PC14      // pin  2
#define DOWN_SET  PC15      // pin  3

TwoWire Wire2(SDA, SCL);    // nastavení pinů pro I2C

SPISettings mySettings(1000000, MSBFIRST, SPI_MODE0);     // nastavení SPI komunikace, maximální rychlost komunikace TLC59283 je 35MHz

int minuty_dec;
int hodiny_dec;
int mode = 0;
int reset = 1;

char16_t hodiny[24] =
{
  0b0011111100000000,     //  0
  0b0000011000000000,     //  1
  0b0101101100000000,     //  2
  0b0100111100000000,     //  3
  0b0110011000000000,     //  4
  0b0110110100000000,     //  5
  0b0111110100000000,     //  6
  0b0000011100000000,     //  7
  0b0111111100000000,     //  8
  0b0110111100000000,     //  9
  0b0011111100000110,     // 10
  0b0000011000000110,     // 11
  0b0101101100000110,     // 12
  0b0100111100000110,     // 13
  0b0110011000000110,     // 14
  0b0110110100000110,     // 15
  0b0111110100000110,     // 16
  0b0000011100000110,     // 17
  0b0111111100000110,     // 18
  0b0110111100000110,     // 19
  0b0011111101011011,     // 20
  0b0000011001011011,     // 21
  0b0101101101011011,     // 22
  0b0100111101011011,     // 23
};

char16_t minuty[60] =
{
  0b0011111100111111,     // 00
  0b0000011000111111,     // 01
  0b0101101100111111,     // 02
  0b0100111100111111,     // 03
  0b0110011000111111,     // 04
  0b0110110100111111,     // 05
  0b0111110100111111,     // 06
  0b0000011100111111,     // 07
  0b0111111100111111,     // 08
  0b0110111100111111,     // 09
  0b0011111100000110,     // 10
  0b0000011000000110,     // 11
  0b0101101100000110,     // 12
  0b0100111100000110,     // 13
  0b0110011000000110,     // 14
  0b0110110100000110,     // 15
  0b0111110100000110,     // 16
  0b0000011100000110,     // 17
  0b0111111100000110,     // 18
  0b0110111100000110,     // 19
  0b0011111101011011,     // 20
  0b0000011001011011,     // 21
  0b0101101101011011,     // 22
  0b0100111101011011,     // 23
  0b0110011001011011,     // 24
  0b0110110101011011,     // 25
  0b0111110101011011,     // 26
  0b0000011101011011,     // 27
  0b0111111101011011,     // 28
  0b0110111101011011,     // 29
  0b0011111101001111,     // 30
  0b0000011001001111,     // 31
  0b0101101101001111,     // 32
  0b0100111101001111,     // 33
  0b0110011001001111,     // 34
  0b0110110101001111,     // 35
  0b0111110101001111,     // 36
  0b0000011101001111,     // 37
  0b0111111101001111,     // 38
  0b0110111101001111,     // 39
  0b0011111101100110,     // 40
  0b0000011001100110,     // 41
  0b0101101101100110,     // 42
  0b0100111101100110,     // 43
  0b0110011001100110,     // 44
  0b0110110101100110,     // 45
  0b0111110101100110,     // 46
  0b0000011101100110,     // 47
  0b0111111101100110,     // 48
  0b0110111101100110,     // 49
  0b0011111101101101,     // 50
  0b0000011001101101,     // 51
  0b0101101101101101,     // 52
  0b0100111101101101,     // 53
  0b0110011001101101,     // 54
  0b0110110101101101,     // 55
  0b0111110101101101,     // 56
  0b0000011101101101,     // 57
  0b0111111101101101,     // 58
  0b0110111101101101,     // 59
};

// Convert normal decimal numbers to binary coded decimal
byte decToBcd(byte val){
    return( (val/10*16) + (val%10) );
}

// Convert binary coded decimal to normal decimal numbers
byte bcdToDec(byte val){
    return( (val/16*10) + (val%16) );
}

void setup() {
  pinMode(SCLK, OUTPUT);
  pinMode(MISO, INPUT);
  pinMode(MOSI, OUTPUT);
  pinMode(LAT1, OUTPUT);
  pinMode(BLANK1, OUTPUT);
  pinMode(LAT2, OUTPUT);
  pinMode(BLANK2, OUTPUT);
  pinMode(MAIN_SET, INPUT);
  pinMode(UP_SET, INPUT);
  pinMode(DOWN_SET, INPUT);
  
  digitalWrite(SCLK, LOW);
  digitalWrite(MISO, LOW);
  digitalWrite(MOSI, LOW);
  digitalWrite(LAT1, HIGH);
  digitalWrite(BLANK1, HIGH);
  digitalWrite(LAT2, HIGH);
  digitalWrite(BLANK2, HIGH);
  digitalWrite(SDA, LOW);
  digitalWrite(SCL, LOW);
  digitalWrite(MAIN_SET, HIGH);
  digitalWrite(UP_SET, HIGH);
  digitalWrite(DOWN_SET, HIGH);

  SPI.setMOSI(MOSI);                       // nastavení pinů pro SPI
  SPI.setMISO(MISO);                       // nastavení pinů pro SPI
  SPI.setSCLK(SCLK);                       // nastavení pinů pro SPI

  Wire2.begin();                           // inicializace Wire (I2C) knihovny
  //SPI.begin();                           // inicializace SPI knihovny, nemusí se použít, používám mySettings
}

void loop() {

  if (reset == 1) {                        // funkce na zjištění zda bylo přerušeno napájení RTC čipu (vybitá baterie + výpadek proudu ze sítě) a zapne nastavení hodin 
    Wire2.beginTransmission(0x68);
    Wire2.write(1);                        // nastaví počáteční registr odkud se má číst
    Wire2.endTransmission();
    Wire2.requestFrom(0x68, 2);            // vyžádá data z dvou registrů
  
    minuty_dec = bcdToDec(Wire2.read());   // načte minuty z registru
    hodiny_dec = bcdToDec(Wire2.read());   // načte hodiny z následujícího registru

    if (hodiny_dec == 0 and minuty_dec == 0) {
      mode = 1;
    }
    reset = 0;
  } 


  if (digitalRead(MAIN_SET) == 0) {        // zapne nastavování hodin
    mode = 1;
  }

  // MODE 0 - standardní běh hodin
  if (mode == 0) {
    Wire2.beginTransmission(0x68);
    Wire2.write(1);                        // nastaví počáteční registr odkud se má číst
    Wire2.endTransmission();
    Wire2.requestFrom(0x68, 2);            // vyžádá data z dvou registrů
  
    minuty_dec = bcdToDec(Wire2.read());   // načte minuty z registru
    hodiny_dec = bcdToDec(Wire2.read());   // načte hodiny z následujícího registru
  
    digitalWrite(BLANK1, HIGH);            // zhasne display
    digitalWrite(BLANK2, HIGH);            // zhasne display
  
    SPI.beginTransaction(mySettings);
    SPI.transfer16(minuty[minuty_dec]);    // druhý číslo, první číslo
    SPI.transfer16(hodiny[hodiny_dec]);    // druhý číslo, první číslo
    SPI.endTransaction();
  
    digitalWrite(BLANK1, LOW);             // rozsvítí display
    digitalWrite(BLANK2, LOW);             // rozsvítí display
  }

  // MODE 1 - nastavení hodin
  if (mode == 1) {
    SPI.beginTransaction(mySettings);
    SPI.transfer16(minuty[minuty_dec]);    // druhý číslo, první číslo
    SPI.transfer16(hodiny[hodiny_dec]);
    SPI.endTransaction();

    digitalWrite(BLANK1, HIGH);            // blikne dispayem
    delay(150);                            // blikne dispayem
    digitalWrite(BLANK1, LOW);             // blikne dispayem
    delay(150);                            // blikne dispayem

    if (digitalRead(UP_SET) == 0) {
      hodiny_dec = hodiny_dec + 1;
        if (hodiny_dec > 23) {
          hodiny_dec = 0;
        }
    }

    if (digitalRead(DOWN_SET) == 0) {
      hodiny_dec = hodiny_dec - 1;
        if (hodiny_dec < 0) {
          hodiny_dec = 23;
        }
    }

    if (digitalRead(MAIN_SET) == 0) {
      mode = 2;
    }
  }

  // MODE 2 - nastavení minut
  if (mode == 2) {
    SPI.beginTransaction(mySettings);
    SPI.transfer16(minuty[minuty_dec]); 
    SPI.transfer16(hodiny[hodiny_dec]);
    SPI.endTransaction();

    digitalWrite(BLANK2, HIGH);
    delay(150);
    digitalWrite(BLANK2, LOW);
    delay(150);

    if (digitalRead(UP_SET) == 0) {
      minuty_dec = minuty_dec + 1;
        if (minuty_dec > 59) {
          minuty_dec = 0;
        }
    }

    if (digitalRead(DOWN_SET) == 0) {
      minuty_dec = minuty_dec - 1;
        if (minuty_dec < 0) {
          minuty_dec = 59;
        }
    }
    
    if (digitalRead(MAIN_SET) == 0) {
      mode = 3;
    }
  }

  // MODE 3 - uložení nastavení hodin a minut do RTC čipu
  if (mode == 3) {
    Wire2.beginTransmission(0x68);
    Wire2.write(0);                        // nastaví počáteční registr kam se má ukládat
    Wire2.write(decToBcd(0));              // uloží sekundy (0 sekund) do registru
    Wire2.write(decToBcd(minuty_dec));     // uloží minuty do následujícího registru
    Wire2.write(decToBcd(hodiny_dec));     // uloží hodiny do následujícího registru
    Wire2.endTransmission();

    mode = 0;
    delay(500);
  }
}